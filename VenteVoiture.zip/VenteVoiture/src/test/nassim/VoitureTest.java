package nassim;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Assertions.*;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class VoitureTest {
    @Test
    public void when_getprix_should_correct_price(){
        //init
        Voiture voiture = new Voiture("Renault",50000);

        //Act
        int expectedPrice=50000;
        int price=voiture.getPrix();

        //test
        assertEquals(expectedPrice,price,"C'est pas egal");
    }
    @Test
    public void when_getmarque_should_correct_price(){

        //init
        Voiture voiture = new Voiture("Alfa Romeo",10000);


        //Act
        String expectedmarque = "Alfa Romeo";
        String marque= voiture.getMarque();

        //test
        assertEquals(expectedmarque,marque,"La marque ne correspond pas");


    }
    @Test
    public void when_tostring_should_correct_price(){
        //init
        Voiture voiture = new Voiture("Ferrari",100000);

        //Act
        String expectedtoString = "La to String Marque : "+voiture.getMarque()+" au prix "+voiture.getPrix();
        String tostring = voiture.toString();


        //test

        assertEquals(expectedtoString,tostring,"La to String n'est pas égal");
    }
    @Test
    public void when_setPrix_should_correct_price(){
        //init
        Voiture voiture = new Voiture("Dacia",500);
        voiture.setPrix(5000);

        //act
        int expectedSetPrice=5000;
        int price=voiture.getPrix();

        //test
        assertEquals(expectedSetPrice,price,"C'est pas egal");

    }

    @Test
    public void when_setMarque_should_correct_marque(){

        //init
        Voiture voiture = new Voiture("Mercedes Benz",500);
        voiture.setMarque("Jouets Clubs");

        //act
        String expectedSetMarque="Jouets Clubs";
        String marque = voiture.getMarque();

        //test

        assertEquals(expectedSetMarque,marque,"La marque n'est pas égal");
    }


}
