package nassim;

public class Voiture {
    private String marque;
    private int prix;
    public Voiture(String marque, int prix){
           this.prix = prix;
           this.marque = marque;
    }
    public void setMarque(String marque) {
        this.marque = marque;
    }

    public void setPrix(int prix) {
        this.prix = prix;
    }

    public int getPrix() {
        return prix;
    }

    public String getMarque() {
        return marque;
    }

    @Override
    public String toString() {
        return "La to String Marque : "+getMarque()+" au prix "+getPrix();
    }
}
