##############
# SAE S01.01 #
##############

def liste_amis(amis, prenom):
    """
        Retourne la liste des amis de prenom en fonction du tableau amis.
    """
    prenoms_amis = []
    i = 0
    while i < len(amis)//2:
        if amis[2 * i] == prenom:
            prenoms_amis.append(amis[2*i+1])
        elif amis[2*i+1] == prenom:
            prenoms_amis.append(amis[2*i])
        i += 1
    return prenoms_amis

def nb_amis(amis, prenom):
    """ Retourne le nombre d'amis de prenom en fonction du tableau amis. """
    return len(liste_amis(amis, prenom))


def personnes_reseau(amis):
    """ Retourne un tableau contenant la liste des personnes du réseau."""
    people = []
    i = 0
    while i < len(amis):
        if amis[i] not in people:
            people.append(amis[i])
        i += 1
    return people

def taille_reseau(amis):
    """ Retourne le nombre de personnes du réseau."""
    return len(personnes_reseau(amis))

def lecture_reseau(path):
    """ Retourne le tableau d'amis en fonction des informations contenues dans le fichier path."""
    f = open(path, "r")
    l = f.readlines()
    f.close()
    amis = []
    i = 0
    while i < len(l):
        fr = l[i].split(";")
        amis.append(fr[0].strip())
        amis.append(fr[1].strip())
        i += 1
    return amis

def dico_reseau(amis):
    """ Retourne le dictionnaire correspondant au réseau."""
    dico = {}
    people = personnes_reseau(amis)
    i = 0
    while i < len(people):
        dico[people[i]] = liste_amis(amis, people[i])
        i += 1
    return dico

def nb_amis_plus_pop (dico_reseau):
    """ Retourne le nombre d'amis des personnes ayant le plus d'amis."""
    personnes = list(dico_reseau)
    maxi = len(dico_reseau[personnes[0]])
    i = 1
    while i < len(personnes):
        if maxi < len(dico_reseau[personnes[i]]):
            maxi = len(dico_reseau[personnes[i]])
        i += 1
    return maxi


def les_plus_pop (dico_reseau):
    """ Retourne les personnes les plus populaires, c'est-à-dire ayant le plus d'amis."""
    max_amis = nb_amis_plus_pop(dico_reseau)
    most_pop = []
    personnes = list(dico_reseau)
    i = 1
    while i < len(personnes):
        if len(dico_reseau[personnes[i]]) == max_amis:
            most_pop.append(personnes[i])
        i += 1
    return most_pop

##############
# SAE S01.02 #
##############

def create_network(list_of_friends):
    '''
    La fonction create_network prends en paramètre un réseau d'amis. Cette fonction va créer un dictionnaire contenant
    en clé le nom des personnes de ce réseau et les valeurs seront un tableau qu'il va créer contenant tout les amis
    de la personne en clé
    '''
    network={}
    i=0
    while i < len(list_of_friends):
        if not list_of_friends[i] in network:
            network[list_of_friends[i]] = [list_of_friends[i+1]]
            
            network[list_of_friends[i+1]] = [list_of_friends[i]]
        else:
            network[list_of_friends[i]].append(list_of_friends[i+1])
            
            if not list_of_friends[i+1] in network:
                
                network[list_of_friends[i+1]] = [list_of_friends[i]]
            else:
                network[list_of_friends[i+1]].append(list_of_friends[i])
        i+=2
    return network


def get_people(network):
    """
    La fonction prend en paramètre un réseau et retourne la liste des personnes de ce réseau dans un tableau
    """
    return list(network)

def are_friends(network, person1, person2):
    """
    La fonction prend en paramètre un réseau ainsi que 2 personnes. La fonction devra retourner True si les deux personnes sont amies, et False sinon
    """
    if person2 in network[person1] and person1 in network[person2]: #Si la 2e personne est dans le réseau de la première et inversement, alors ils sont amis
        return True
    else:
        return False
    
    
def all_his_friends(network, person, group):
    """
    All_his_friends prend en paramètre un réseau, une personne et un groupe de personne, cette fonction retourne True sur la personne est ami avec toutes les personnes du groupes
    et elle retourne False dans le cas contraire
    """
    i=0
    while i < len(group):
        if are_friends(network,person,group[i]):# on test via la fonction précédemment crée si person est ami avec l'un des personne du groupe
            i+=1 #si elle return true alors on passe a une autre personne du groupe pour tester à nouveau 
        else:
            return False
    return True



def is_a_community(network, group):
    """
    Cette fonction prenant en paramètre un dictionnaire modélisant le réseau et un groupe 
    et retourne True si ce groupe est une communauté, et False sinon
    """
    i=0 
    while i < len(group): 
        tab2 = group.copy() # A chaque itération, elle crée une copie du groupe "tab2"
        del(tab2[i]) # Et supprime l'élément actuel de la boucle de cette copie.
        if all_his_friends(network,group[i],tab2): # Test de "all_his_friends" avec les paramètres network, l'élément actuel de la boucle et "tab2"
            i+=1
        else:
            return False #Si la fonction "all_his_friends" renvoit False à un momement, alors "is_a_community" renverra False aussi
    return True

def find_community(network,group):
    """
    Cette fonction prend en paramètre un réseau et un groupe, elle retourne une communauté en fonction de d'une heuristique donnée. 
    L'heuristique :
    On part d'une communauté vide.
    On considère les personnes les unes après les autres. Pour chacune des personnes, si celle-ci est amie avec tous les membres de la communauté déjà créée, alors on l'ajoute à la communauté.
    """
    tab=[]
    i=1
    tab.append(group[0])
    while i < len(group):
        if all_his_friends(network,group[i],tab): #A chaque itération, elle vérifie si l'élément actuel est ami avec tous les membres du groupe déjà créé
            tab.append(group[i]) #Si la fonction renvoie true alors il ajoute l'élément actuel dans tab 
        i+=1
    return tab


def order_by_decreasing_popularity(network, group):
    """
    Elle prend en paramètre un réseau et un groupe de personnes et triant le groupe de personnes selon leur popularité et retourne un tableau. 
    Donc celui ou celle qui a le plus d'amis se retrouvera premier et le moins en dernier
    """
    result = [] 
    tmp = group.copy()
    j=0
    while j < len(group): #La boucle sert à reinitialiser la 2nd
        a = 0
        i=0
        while i < len(tmp): #Une seconde boucle pour parcourir le groupe et trouver la personne avec le plus d'amis
            if len(tmp[i])< len(tmp[a]):
                 a = i
            i+=1
        result.append(tmp[a]) #Il ajoute ensuite cette personne à la liste "résultat"
        tmp.pop(a) #la supprime du groupe temporaire "tmp" et continue jusqu'à ce que toutes les personnes du groupe aient été traitées
        j+=1
    return result

def find_community_by_decreasing_popularity(network):
    """
    La fonction doit trier les personnes du réseau selon l'ordre décroissant de popularité puis retourner la communauté trouvée
    """
    group= get_people(network) #récupère les personnes du groupe
    order = order_by_decreasing_popularity(network,group) #Utilise la fonction précedemment crée et l'utilise avec le réseau ainsi que la variable faites au dessus
    result = find_community(network,order)
    return result



def find_community_from_person(network,person):
    """
    Elle prend en paramètre un réseau et une personne, et retournant une communauté maximale
    """
    group = get_people(network)
    commu= [person] # initialise une liste à laquelle on ajoute la personne de départ
    tabtemp = []
    i = 0
    while i < len(group) :
        if are_friends(network, person, group[i]): #La variable tabtemp contiendra toutes les personnes qui sont amies avec la personne de départ
            tabtemp.append(group[i])
        i+=1
        
    tri = order_by_decreasing_popularity(network, tabtemp) #On tri ce tabtemp par popularité des personens
    i = 0
    while i < len(tri):
        commu.append(tri[i]) #On ajoute ce tableau trié à la communauté initialisé au départ
        i+=1
    return commu

def find_max_community(network):
    """
    La fonction prend en paramètre un réseau et applique l'heuristique de recherche de communauté maximale pour toutes les personnes du réseau. 
    Elle doit retourner la plus grande communauté trouvée.
    """
    group = get_people(network) 
    maxi = find_community_from_person(network,group[0]) # On prend la 1ère communauté du Network
    i=0
    while i < len(group): 
        if maxi < find_community_from_person(network,group[i]): # Si cette communauté est plus petite que celle de groupe de i  
            maxi = find_community_from_person(network,group[i]) # La nouvelle communauté dans maxi sera celle de groupe i. Dans le cas contraire on passe simplement à la personne d'après
        i+=1
    return maxi
