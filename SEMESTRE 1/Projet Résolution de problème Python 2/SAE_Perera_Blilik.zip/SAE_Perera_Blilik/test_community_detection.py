from community_detection import*
network = {
    "Alice" : ["Bob", "Dominique"],
    "Bob" : ["Alice", "Charlie", "Dominique"],
    "Charlie" : ["Bob"],
    "Dominique" : ["Alice", "Bob"]
  }
network2 = {
    "Tharindu" : ["Bob", "Nassim"],
    "Bob" : ["Alice", "Charlie", "Dominique","Nassim"],
    "Charlie" : ["Bob"],
    "Nassim" : ["Tharindu", "Bob","Charlie"]
  }
network3 = {
    "Tharindu" : ["Bob", "Nassim","Charlie"],
    "Bob" : ["Alice", "Charlie", "Dominique","Nassim","Tharindu"],
    "Charlie" : ["Bob","Nassim","Tharindu"],
    "Nassim" : ["Tharindu", "Bob","Charlie"]
  }

def test_create_network():
    assert create_network(['Alice','Bob','Bob','Charlie','Alice','Dominique','Bob','Dominique']) == {'Alice': ['Bob', 'Dominique'],'Bob': ['Alice', 'Charlie', 'Dominique'],
                                                                                                     'Charlie': ['Bob'],'Dominique': ['Alice', 'Bob']}
    assert create_network(['Tharindu','Bob','Bob','Charlie','Alice','Nassim','Bob','Dominique']) == {'Tharindu': ['Bob'],'Bob': ['Tharindu', 'Charlie', 'Dominique'],'Charlie': ['Bob'],
                                                                                                     'Alice': ['Nassim'],'Nassim': ['Alice'],
                                                                                                     'Dominique': ['Bob']}
    assert create_network(['Tharindu','Bob','Bob','Charlie','Tharindu','Nassim','Bob','Agash']) == {'Tharindu': ['Bob', 'Nassim'], 'Bob': ['Tharindu', 'Charlie', 'Agash'],
                                                                                                    'Charlie': ['Bob'],'Nassim': ['Tharindu'],
                                                                                                    'Agash': ['Bob']}
    print("Test ok")
    
def test_get_people():
    assert get_people(network) == ['Alice', 'Bob', 'Charlie', 'Dominique']
    assert get_people(network2) == ['Tharindu', 'Bob', 'Charlie', 'Nassim']
    assert get_people(network3) == ['Tharindu', 'Bob', 'Charlie', 'Nassim']
    print("Test ok")


def test_are_firends():
    assert are_friends(network, "Bob", "Alice") == True
    assert are_friends(network, "Charlie", "Dominique") == False
    assert are_friends(network, "Dominique", "Tharindu") == False
    assert are_friends(network, "Alice", "Alice") == False
    assert are_friends(network, "Alice", "Bob") == True
    print("Test ok")
    
    
def test_all_his_friends():
    assert all_his_friends(network, "Dominique", ["Alice", "Charlie", "Dominique"]) == False
    assert all_his_friends(network, "Bob", ["Alice", "Charlie", "Dominique"]) == True
    assert all_his_friends(network, "Charlie", ["Bobb"]) == False
    assert all_his_friends(network, "Alice", ["Bob", "Dominique"]) == True
    print("Test ok")    
    
def test_is_a_community():
    assert is_a_community(network, ["Alice", "Bob", "Dominique"]) == True
    assert is_a_community(network, ["Charlie", "Bob"]) == True
    assert is_a_community(network, ["Alice", "Bob", "Charlie"]) == False
    assert is_a_community(network, ["Alice", "Dominique"]) == True
    print("Test ok")
    
def test_find_community():
    assert find_community(network, ["Alice", "Bob", "Charlie", "Dominique"]) == ["Alice", "Bob", "Dominique"]
    assert find_community(network, ["Charlie", "Bob"]) == ['Charlie', 'Bob']
    assert find_community(network, ["Alice", "Dominique"]) == ['Alice', 'Dominique']
    assert find_community(network2, ["Tharindu", "Nassim","Bob"]) == ['Tharindu', 'Nassim']
    print("Test ok")

def test_order_by_decreasing_popularity():
    assert order_by_decreasing_popularity(network, ["Alice", "Bob", "Charlie", "Dominique"]) == ['Bob', 'Alice','Charlie', "Dominique"]
    assert order_by_decreasing_popularity(network, ["Charlie", "Bob"]) == ['Bob', 'Charlie']
    assert order_by_decreasing_popularity(network, ["Alice", "Dominique"]) == ['Alice', 'Dominique']
    assert order_by_decreasing_popularity(network2, ["Tharindu", "Nassim","Bob"]) == ["Bob",'Nassim','Tharindu']
    print("Test ok")

def test_find_community_by_decreasing_popularity():
    assert find_community_by_decreasing_popularity(network) == ["Bob", "Alice", "Dominique"]
    assert find_community_by_decreasing_popularity(network2) == ['Bob', 'Nassim']
    assert find_community_by_decreasing_popularity(network3) == ['Bob', 'Nassim', 'Charlie', 'Tharindu']
    print("Test ok")

def test_find_community_from_person():
    assert find_community_from_person(network,"Bob") == ['Bob', 'Alice', 'Charlie', 'Dominique']
    assert find_community_from_person(network2,"Nassim") == ['Nassim', 'Bob', 'Tharindu']
    assert find_community_from_person(network3,"Tharindu") == ['Tharindu', 'Bob', 'Nassim', 'Charlie']
    assert find_community_from_person(network2,"Charlie") == ['Charlie', 'Bob']
    print("Test ok")

def test_find_max_community():
    assert find_max_community(network) == ['Bob', 'Alice', 'Dominique']
    assert find_max_community(network2) == ['Nassim', 'Bob', 'Tharindu']
    assert find_max_community(network3) == ['Tharindu', 'Bob', 'Nassim', 'Charlie']
    print("Test ok")